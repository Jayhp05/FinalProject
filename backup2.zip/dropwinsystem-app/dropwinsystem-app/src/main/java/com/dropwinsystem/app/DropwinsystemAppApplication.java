package com.dropwinsystem.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DropwinsystemAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DropwinsystemAppApplication.class, args);
	}

}
