package com.dropwinsystem.app.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.dropwinsystem.app.domain.Member;

@Mapper
public interface MemberMapper {

	public Member getMember(String id);	

	public void addMember(Member member);

	public String memberPassCheck(String id);

	public void updateMember(Member member);
}
