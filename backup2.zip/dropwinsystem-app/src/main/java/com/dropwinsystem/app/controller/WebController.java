package com.dropwinsystem.app.controller;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;

import lombok.extern.slf4j.Slf4j;

/* Spring MVC Controller 클래스 임을 정의
 * @Controller 애노테이션이 적용된 클래스의 메서드는 기본적으로 뷰의 이름을 반환한다.
 **/
@Controller
@Slf4j
public class WebController {
	
	@GetMapping("/")
	public String root() {
		return "redirect:/home";  // 기본 루트는 홈으로 이동
	}

	@GetMapping("/home")
	public String home() {
		return "views/home";
	}

	@GetMapping("/about")
	public String about() {
		return "views/about";
	}

	@GetMapping("/shop")
	public String shop() {
		return "views/shop";
	}

	@GetMapping("/contact")
	public String contact() {
		return "views/contact";
	}

	@GetMapping("/board")
	public String board() {
		return "views/board";
	}

	@GetMapping("/add1")
	public String add1() {
		return "views/add1";
	}
}
