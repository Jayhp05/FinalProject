package com.dropwinsystem.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.dropwinsystem.app.domain.Member;
import com.dropwinsystem.app.mapper.MemberMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MemberService {

	@Autowired
	private MemberMapper memberMapper;

	@Autowired
	private PasswordEncoder passwordEncoder;

	public int login(String id, String pass) {
		int result = -1;
		Member m = memberMapper.getMember(id);

		if(m == null) {
			return result;
		}
	
		if(passwordEncoder.matches(pass, m.getPass())) {
			result = 1;
			
		} else { // 비밀번호가 틀리면 : 0
			result = 0;
		}
		
		return result;
	}
	
	// 회원 ID에 해당하는 회원 정보를 읽어와 반환하는 메서드	
	public Member getMember(String id) {
		return memberMapper.getMember(id);
	}
	
	// 회원 가입시 아이디 중복을 체크하는 메서드	
	public boolean overlapIdCheck(String id) {
		Member member = memberMapper.getMember(id);
		log.info("overlapIdCheck - member : " + member);
		if(member == null) {
			return false;
		}
		return true;
	}

	public void addMember(Member member) {

		member.setPass(passwordEncoder.encode(member.getPass()));

		log.info(member.getPass());
		memberMapper.addMember(member);
	}

	public boolean memberPassCheck(String id, String pass) {		
		
		String dbPass = memberMapper.memberPassCheck(id);		
		boolean result = false;		
	
		if(passwordEncoder.matches(pass, dbPass)) {
			result = true;	
		}
		return result;	
	}

	public void updateMember(Member member) {

		member.setPass(passwordEncoder.encode(member.getPass()));
		log.info(member.getPass());
		
		memberMapper.updateMember(member);
	}	
}
