package com.dropwinsystem.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dropwinsystem.app.domain.Calendar;
import com.dropwinsystem.app.mapper.CalendarMapper;

@Service
public class CalendarServiceImpl implements CalendarService {

	@Autowired
    private CalendarMapper calendarMapper;

    @Override
    public List<Calendar> calendarList() throws Exception {
        return calendarMapper.calendarList();
    }

    @Override
    public void calendarSave(Calendar clalendar) throws Exception {
        calendarMapper.calendarSave(clalendar);
    }

    @Override
    public void calendarDelete(String no) throws Exception {
        calendarMapper.calendarDelete(no);
    }

    @Override
    public void eventUpdate(Calendar clalendar) throws Exception {
        calendarMapper.eventUpdate(clalendar);
    }
}
