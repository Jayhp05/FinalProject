package com.dropwinsystem.app.controller;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dropwinsystem.app.domain.Calendar;
import com.dropwinsystem.app.service.CalendarService;

@RestController
@RequestMapping("/calendar")
public class CalendarController {
	
	@Autowired
    private CalendarService calendarService;

	@GetMapping("/calendar")
	public String calendar() {
		
		return "views/calendar";
	}

    @GetMapping("/calendarList")
    public List<Calendar> calendarList() throws Exception {
        return calendarService.calendarList();
    }

    @PostMapping("/calendarSave")
    public Calendar calendarSave(@RequestBody Map<String, Object> map) throws Exception {
        Calendar calendar = new Calendar();
        calendar.setTitle((String) map.get("title"));

        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
        ZonedDateTime startUTC = ZonedDateTime.parse((String) map.get("start"), formatter).withZoneSameInstant(ZoneId.of("Asia/Seoul"));
        ZonedDateTime endUTC = map.get("end") != null ? ZonedDateTime.parse((String) map.get("end"), formatter).withZoneSameInstant(ZoneId.of("Asia/Seoul")) : null;

        calendar.setStart1(startUTC.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        calendar.setEnd(endUTC != null ? endUTC.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) : null);
        calendar.setAllDay((Boolean) map.get("allDay"));

        calendarService.calendarSave(calendar);

        return calendar;
    }

    @DeleteMapping("/calendarDelete")
    public String calendarDelete(@RequestParam String no) throws Exception {
        try {
            calendarService.calendarDelete(no);
            return "success";
        } catch (Exception e) {
            e.printStackTrace();
            return "fail";
        }
    }

    @PutMapping("/eventUpdate/{no}")
    public String eventUpdate(@PathVariable String no, @RequestBody Map<String, Object> map) {
        Calendar calendar = new Calendar();
        calendar.setCalendarNo(Long.valueOf(no));
        calendar.setTitle((String) map.get("title"));
        calendar.setStart1(map.get("start1").toString().substring(0, 19));
        if (map.get("end") != null) {
            calendar.setEnd(map.get("end").toString().substring(0, 19));
        }
        calendar.setAllDay((Boolean) map.get("allDay"));

        try {
            calendarService.eventUpdate(calendar);
            return "success";
        } catch (Exception e) {
            e.printStackTrace();
            return "fail";
        }
    }

}