package com.dropwinsystem.app.controller;

import java.io.IOException;
import java.io.PrintWriter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.dropwinsystem.app.domain.Member;
import com.dropwinsystem.app.service.MemberService;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;

@Controller
@SessionAttributes("member")
@Slf4j
public class MemberController {
	
	// 회원 관련 Business 로직을 담당하는 객체를 의존성 주입하도록 설정
	@Autowired
	private MemberService memberService;
	 
	@PostMapping("/login")	
	public String login(Model model, @RequestParam("userId") String id, 
			@RequestParam("pass") String pass, 
			HttpSession session, HttpServletResponse response) 
					throws ServletException, IOException {
		log.info("MemberController.login()");

		int result = memberService.login(id, pass);
		
		if(result == -1) { // 회원 아이디가 존재하지 않으면
			response.setContentType("text/html; charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("	alert('존재하지 않는 아이디 입니다.');");
			out.println("	history.back();");
			out.println("</script>");

			return null;
			
		} else if(result == 0) { // 비밀번호가 틀리면
			response.setContentType("text/html; charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("	alert('비밀번호가 다릅니다.');");
			out.println("	location.href='loginForm'");
			out.println("</script>");
			
			return null;
		}		

		Member member = memberService.getMember(id);
		session.setAttribute("isLogin", true);

		model.addAttribute("member", member);
		System.out.println("member.name : " + member.getName());
	
		return "redirect:/noticeList";
	}

	@GetMapping("/memberLogout")
	public String logout(HttpSession session) {	
		log.info("MemberController.logout(HttpSession session)");

		session.invalidate();

		return "redirect:/loginForm";
	}

	@RequestMapping("/overlapIdCheck")

	public String overlapIdCheck(Model model, @RequestParam("id") String id) {		

		boolean overlap = memberService.overlapIdCheck(id);

		model.addAttribute("id", id);
		model.addAttribute("overlap", overlap);

		return "member/overlapIdCheck.html";
	}

	@PostMapping("/joinResult")
	public String joinResult(Model model, Member member,
			@RequestParam("pass1") String pass1, 
			@RequestParam("emailId") String emailId, 
			@RequestParam("emailDomain") String emailDomain,
			@RequestParam("mobile1") String mobile1, 
			@RequestParam("mobile2") String mobile2, 
			@RequestParam("mobile3") String mobile3,
			@RequestParam(value="emailGet", required=false, 
				defaultValue="false")boolean emailGet) {		
		
		member.setPass(pass1);
		member.setEmail(emailId + "@" + emailDomain);
		member.setMobile(mobile1 + "-" + mobile2 + "-" + mobile3);

		member.setEmailGet(Boolean.valueOf(emailGet));

		memberService.addMember(member);
		log.info("joinResult : " + member.getName());

		return "redirect:loginForm";
	}

	@GetMapping("/memberUpdateForm")
	public String updateForm(Model model, HttpSession session) {		

		return "member/memberUpdateForm";
	}	

	@PostMapping("/memberUpdateResult")
	public String memberUpdateInfo(Model model, Member member,
			@RequestParam("pass1") String pass1, 
			@RequestParam("emailId") String emailId, 
			@RequestParam("emailDomain") String emailDomain,
			@RequestParam("mobile1") String mobile1, 
			@RequestParam("mobile2") String mobile2, 
			@RequestParam("mobile3") String mobile3,
			@RequestParam(value="emailGet", required=false, 
				defaultValue="false")boolean emailGet) {
		
		member.setPass(pass1);
		member.setEmail(emailId + "@" + emailDomain);
		member.setMobile(mobile1 + "-" + mobile2 + "-" + mobile3);

		member.setEmailGet(Boolean.valueOf(emailGet));	

		memberService.updateMember(member);		
		log.info("memberUpdateResult : " + member.getId());

		model.addAttribute("member", member);

		return "redirect:noticeList";
	}
}
